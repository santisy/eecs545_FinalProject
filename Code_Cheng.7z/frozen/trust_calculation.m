%% Calculate trust value for the trust network in Epinion dataset
% Author: Cheng Ouyang
% This script calculate trust value in Epinion dataset
% With reference to SoRec PMF paper by Hao Ma
[m1,~] = size(trustnetwork);
minDeg = zeros(22166,1); % outgoing degree(influence to other people)
plusDeg = zeros(22166,1); % incoming degree(influnced by other people)
for i = 1:22166 % calculate degree
    minDeg(i) = length(find(trustnetwork(:,2) == i));
    plusDeg(i) = length(find(trustnetwork(:,1) == i));
end
% calculate the score and map to 1-5
trustnetwork(:,4) = 4*(sqrt(minDeg(trustnetwork(:,2))./(plusDeg(trustnetwork(:,1)) + minDeg(trustnetwork(:,2)))))+1;

    