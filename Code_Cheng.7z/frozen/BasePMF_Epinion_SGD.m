
%% Basic PMF on Epinion Dataset
% Author: Cheng Ouyang
% This script performs basic PMF on Epinion Dataset using stochastic
% gradient descent
% Parameters are set as descripted
% With reference to PMF paper and demo by Ruslan Salakhutdinov

% read dataset
clear
clc
load epinion

% paramter initialization
NUM_USER = 22166;
NUM_MOVIE = 296277;

lambdaU  = 0.01 
lambdaP = 0.01 % regularization on U and P  
featureDim = 8 % demension of feature vector
testIdx = 1 % indicating which fold is used as testing data
maxIterNum = 50; % maximun rounds of iteration
numBatch = 10; % number of batches
gamma = 0.8; % coefficient for velocity
alpha = 0.0005; % learning rate
trainMatrix = []; % split the data into training set and testing set
testMatrix = [];
for i = 1:5
    if i == testIdx
        testMatrix = rating{i};
    else
        trainMatrix = [trainMatrix;rating{i}];
    end
end

allData = [trainMatrix;testMatrix];
[numData,~] = size([allData]);
trainMatrix = trainMatrix(:,1:3);
testMatrix = testMatrix(:,1:3);
allData = allData(:,1:3);
[numTrain,~] = size(trainMatrix);
[numTest,~] = size(testMatrix);
batchSize = floor(numTrain/numBatch); % size for each batch

% feature initializtion
P = 0.1*randn(NUM_MOVIE, featureDim); % Movie feature vectors
U = 0.1*randn(NUM_USER, featureDim); % User feature vecators

dP = zeros(NUM_MOVIE, featureDim); % gradients
dU = zeros(NUM_USER, featureDim); 
vU = zeros(NUM_USER, featureDim); % velocity
vP = zeros(NUM_MOVIE, featureDim);

ratingMean = mean(trainMatrix(:,3));
trainMatrix(:,3) = trainMatrix(:,3) - ratingMean; % move to zero-mean
RMSEList = [];
MAEList = [];

% SGD iteration
for currentIter = 1:maxIterNum
    % permutate training samples
    updateIdx = randperm(numTrain);
    trainMatrix = trainMatrix(updateIdx,:);
    % sub-iterations
    for batch = 1:numBatch
        % find the indices of user, item and rating of training data inside
        % the batch
        userSampleID = double(trainMatrix(batchSize*(batch-1)+1:batchSize*batch,1));
        movieSampleID = double(trainMatrix(batchSize*(batch-1)+1:batchSize*batch,2));
        ratingSample = double(trainMatrix(batchSize*(batch-1)+1:batchSize*batch,3));
        % calculate training error
        prediction = sum(P(movieSampleID,:).* U(userSampleID,:),2);
        error = repmat(2*(prediction - ratingSample),1,featureDim);
        % calculate gradient
        updateU = error.*P(movieSampleID,:) + lambdaU*U(userSampleID,:);
        updateP = error.*U(userSampleID,:) + lambdaP*P(movieSampleID,:);
        dU = zeros(NUM_USER,featureDim);
        dP = zeros(NUM_MOVIE,featureDim);
        % summing up gradients
        for idx = 1:batchSize
            dU(userSampleID(idx),:) =  dU(userSampleID(idx),:) + updateU(idx,:);
            dP(movieSampleID(idx),:) =  dP(movieSampleID(idx),:) + updateP(idx,:);
        end
        % update velocities
        vU = gamma.*vU + alpha.*dU;
        vP = gamma.*vP + alpha.*dP;
        % update feature matrices
        U = U - vU;
        P = P - vP;
        
        fprintf('the %1.0f th batch has finished \n', batch);
    end

    % calculate training error
    prediction = sum(P(trainMatrix(:,2),:).*U(trainMatrix(:,1),:),2);
    % objFunction = sum(prediction - ratingSample).^2 + 0.5*lambdaU*(norm(U,'fro').^2) + 0.5*lambdaP*((norm(P,'fro')).^2); 
    trainError = sqrt(sum((prediction - trainMatrix(:,3)).^2,1)./numTrain); 
    
    % calculate test error
    userTestID = double(testMatrix(:,1));
    movieTestID = double(testMatrix(:,2));
    ratingTest = double(testMatrix(:,3));
    testPrediction = sum(P(movieTestID,:).*U(userTestID,:),2)+ratingMean;

    testPrediction(find(testPrediction>5)) = 5; 
    testPrediction(find(testPrediction<1)) = 1; 
  
    testRMSE = sqrt(sum((testPrediction - ratingTest).^2)/numTest);
    testMAE = sum(abs(testPrediction - ratingTest))./numTest;
    RMSEList = [RMSEList,testRMSE];
    MAEList = [MAEList,testMAE];
    % show rsult
    fprintf('the %1.1f iteration finished, training RMSE = %6.4f ,test RMSE = %6.4f, test MAE = %6.4f  \n', ...
              currentIter, trainError,testRMSE,testMAE);  
end 




